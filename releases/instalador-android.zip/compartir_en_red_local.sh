#!/bin/bash
cd "$(dirname "$0")"
echo "=================================================="
echo " SERVIDOR DE DESCARGA RÁPIDA PARA CELULARES       "
echo "=================================================="
echo "Abre la siguiente dirección en el navegador de tu celular"
echo "conectado a la misma red Wi-Fi:"
IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "localhost")
echo "--> http://$IP:8090/Calculadora-Tahoe.apk"
python3 -m http.server 8090
