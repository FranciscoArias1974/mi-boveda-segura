@echo off
title Servidor Local para Android - Custodio Credenciales
cd /d "%~dp0\app"

echo ================================================================
echo    [?] INSTALADOR DE CUSTODIO CREDENCIALES PARA ANDROID
echo ================================================================
echo.
echo Paso 1: Conecta tu telefono Android a la misma red Wi-Fi.
echo.
echo Paso 2: Descubre la IP de tu PC ejecutando "ipconfig" (ej. 192.168.1.50).
echo.
echo Paso 3: En Chrome desde tu Android entra a:
echo    http://TU-IP-LOCAL:8000
echo.
echo Paso 4: En Chrome en Android toca los 3 puntos (:) y selecciona:
echo    "Instalar aplicacion" o "Agregar a la pantalla principal".
echo.
echo ================================================================
echo Servidor iniciado...
echo.

python -m http.server 8000 --bind 0.0.0.0 || py -m http.server 8000 --bind 0.0.0.0
pause
