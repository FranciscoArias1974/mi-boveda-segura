#!/bin/bash
# ==============================================================================
# LANZADOR Y COMPARTIDOR PARA INSTALAR EN ANDROID / MÓVILES
# ==============================================================================

DIR="$(cd "$(dirname "$0")/app" && pwd)"
cd "$DIR" || exit 1

IP_LOCAL=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}')
[ -z "$IP_LOCAL" ] && IP_LOCAL="TU-DIRECCION-IP"

echo "================================================================"
echo "   📱 INSTALADOR DE CUSTODIO CREDENCIALES PARA ANDROID 📱"
echo "================================================================"
echo ""
echo "¡Tu servidor local para Android está activo!"
echo ""
echo "PASO 1: Asegúrate de que tu teléfono Android esté conectado"
echo "        a la misma red Wi-Fi que esta computadora."
echo ""
echo "PASO 2: Abre el navegador Google Chrome en tu Android y entra a:"
echo ""
echo "   👉  http://${IP_LOCAL}:8000"
echo ""
echo "PASO 3: En Chrome en tu Android, toca los 3 puntitos de arriba (⋮)"
echo "        y selecciona: 'Instalar aplicación' o 'Agregar a la pantalla principal'."
echo ""
echo "✅ ¡Listo! Se creará el ícono en tu teléfono y funcionará con tu huella digital."
echo "================================================================"
echo "Servidor corriendo... (Para detener, cierra esta ventana)"
echo ""

python3 -m http.server 8000 --bind 0.0.0.0
