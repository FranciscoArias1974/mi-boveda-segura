@echo off
chcp 65001 >nul
title Desinstalador - Calculadora Tahoe
color 0C

echo ===================================================================
echo               DESINSTALADOR DE CALCULADORA TAHOE
echo ===================================================================
echo.
set /p CONFIRM="¿Desea desinstalar la Calculadora Tahoe de este equipo? (S/N): "
if /i not "%CONFIRM%"=="S" (
    echo Operacion cancelada.
    pause
    exit /b
)

echo Eliminando archivos instalados...
set "INSTALL_DIR=%LOCALAPPDATA%\CalculadoraTahoe"
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"

echo Eliminando accesos directos...
del "%USERPROFILE%\Desktop\Calculadora Tahoe.lnk" 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Calculadora Tahoe.lnk" 2>nul

echo.
echo La Calculadora Tahoe ha sido desinstalada correctamente.
pause
exit
