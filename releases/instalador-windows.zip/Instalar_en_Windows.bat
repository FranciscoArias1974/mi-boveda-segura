@echo off
chcp 65001 >nul
title Instalador - Calculadora macOS Tahoe para Windows
color 0B

echo ===================================================================
echo     INSTALADOR DE CALCULADORA ESTILO MACOS TAHOE PARA WINDOWS
echo ===================================================================
echo.
echo [1/3] Preparando directorio en el sistema...
set "INSTALL_DIR=%LOCALAPPDATA%\CalculadoraTahoe"

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo [2/3] Copiando archivos de la aplicacion...
xcopy /E /I /Y "%~dp0app\*" "%INSTALL_DIR%\" >nul

echo [3/3] Creando accesos directos en Escritorio y Menu Inicio...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; " ^
  "$desktop = [Environment]::GetFolderPath('Desktop'); " ^
  "$sDesktop = $ws.CreateShortcut(\"$desktop\Calculadora Tahoe.lnk\"); " ^
  "$sDesktop.TargetPath = 'wscript.exe'; " ^
  "$sDesktop.Arguments = '\"%INSTALL_DIR%\launcher.vbs\"'; " ^
  "$sDesktop.WorkingDirectory = '%INSTALL_DIR%'; " ^
  "$sDesktop.Description = 'Calculadora estilo macOS Tahoe'; " ^
  "$sDesktop.Save(); " ^
  "$startMenu = [Environment]::GetFolderPath('Programs'); " ^
  "$sMenu = $ws.CreateShortcut(\"$startMenu\Calculadora Tahoe.lnk\"); " ^
  "$sMenu.TargetPath = 'wscript.exe'; " ^
  "$sMenu.Arguments = '\"%INSTALL_DIR%\launcher.vbs\"'; " ^
  "$sMenu.WorkingDirectory = '%INSTALL_DIR%'; " ^
  "$sMenu.Description = 'Calculadora estilo macOS Tahoe'; " ^
  "$sMenu.Save();"

echo.
echo ===================================================================
echo  INSTALACION COMPLETADA CON EXITO!
echo  Se ha creado el acceso directo 'Calculadora Tahoe' en tu Escritorio.
echo ===================================================================
echo.
echo Iniciando Calculadora...
wscript "%INSTALL_DIR%\launcher.vbs"

timeout /t 3 >nul
exit
