/**
 * Calculadora macOS Tahoe - Motor Matemático
 * Inspirado fielmente en la calculadora de Apple para macOS Tahoe / Sequoia e iOS
 */

class TahoeCalculatorEngine {
  constructor() {
    this.resetAll();
    this.memory = 0;
    this.angleMode = 'rad'; // 'rad' o 'deg'
    this.isSecond = false;  // modo alternativo 2nd
    this.history = this.loadHistory();
    this.onStateChange = null;
  }

  resetAll() {
    this.currentValue = '0';
    this.previousValue = null;
    this.operator = null;
    this.waitingForOperand = false;
    this.expressionTokens = [];
    this.lastCalculation = null;
  }

  // --- PERSISTENCIA DE HISTORIAL ---
  loadHistory() {
    try {
      const data = localStorage.getItem('tahoe_calc_history');
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  saveHistory() {
    try {
      localStorage.setItem('tahoe_calc_history', JSON.stringify(this.history.slice(0, 100)));
    } catch (e) {
      console.warn('Error al guardar historial:', e);
    }
  }

  addToHistory(expression, result) {
    const item = {
      id: Date.now().toString(36) + Math.random().toString(36).substr(2, 4),
      expression,
      result,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      date: new Date().toLocaleDateString()
    };
    this.history.unshift(item);
    if (this.history.length > 100) this.history.pop();
    this.saveHistory();
  }

  clearHistory() {
    this.history = [];
    this.saveHistory();
  }

  // --- ENTRADA DE NÚMEROS Y DÍGITOS ---
  inputDigit(digit) {
    if (this.waitingForOperand) {
      this.currentValue = String(digit);
      this.waitingForOperand = false;
    } else {
      if (this.currentValue === '0' || this.currentValue === '-0') {
        this.currentValue = String(digit);
      } else if (this.currentValue.length < 16) {
        this.currentValue += String(digit);
      }
    }
  }

  inputDecimal() {
    if (this.waitingForOperand) {
      this.currentValue = '0.';
      this.waitingForOperand = false;
      return;
    }
    if (!this.currentValue.includes('.')) {
      this.currentValue += '.';
    }
  }

  backspace() {
    if (this.waitingForOperand) return;
    if (this.currentValue.length > 1) {
      this.currentValue = this.currentValue.slice(0, -1);
      if (this.currentValue === '-') this.currentValue = '0';
    } else {
      this.currentValue = '0';
    }
  }

  clear() {
    if (this.currentValue !== '0') {
      this.currentValue = '0';
    } else {
      this.resetAll();
    }
  }

  clearAll() {
    this.resetAll();
  }

  toggleSign() {
    const num = parseFloat(this.currentValue);
    if (isNaN(num)) return;
    this.currentValue = this.formatResult(-num);
  }

  percentage() {
    const val = parseFloat(this.currentValue);
    if (isNaN(val)) return;
    if (this.previousValue !== null && ['+', '-'].includes(this.operator)) {
      // Como Apple: 100 + 10% = 100 + 10 = 110
      const percentVal = (this.previousValue * val) / 100;
      this.currentValue = this.formatResult(percentVal);
    } else {
      this.currentValue = this.formatResult(val / 100);
    }
  }

  // --- OPERADORES BINARIOS (+, -, ×, ÷, xʸ, ʸ√x, EE) ---
  setOperator(nextOperator) {
    const inputValue = parseFloat(this.currentValue);

    if (this.operator && this.waitingForOperand) {
      this.operator = nextOperator;
      return;
    }

    if (this.previousValue === null && !isNaN(inputValue)) {
      this.previousValue = inputValue;
    } else if (this.operator) {
      const result = this.executeBinaryOp(this.operator, this.previousValue, inputValue);
      this.currentValue = this.formatResult(result);
      this.previousValue = result;
    }

    this.waitingForOperand = true;
    this.operator = nextOperator;
  }

  executeBinaryOp(op, a, b) {
    switch (op) {
      case '+': return a + b;
      case '-': return a - b;
      case '×':
      case '*': return a * b;
      case '÷':
      case '/': return b === 0 ? NaN : a / b;
      case 'xʸ':
      case '^': return Math.pow(a, b);
      case 'ʸ√x': return b === 0 ? NaN : Math.pow(a, 1 / b);
      case 'EE': return a * Math.pow(10, b);
      default: return b;
    }
  }

  calculateEquals() {
    if (!this.operator && !this.lastCalculation) return;

    let a, b, op;
    if (this.operator) {
      a = this.previousValue;
      b = parseFloat(this.currentValue);
      op = this.operator;
      this.lastCalculation = { op, b };
    } else if (this.lastCalculation) {
      // Repite última operación (comportamiento idéntico a Apple)
      a = parseFloat(this.currentValue);
      b = this.lastCalculation.b;
      op = this.lastCalculation.op;
    }

    const result = this.executeBinaryOp(op, a, b);
    const formattedResult = this.formatResult(result);
    const exprText = `${this.formatDisplayNumber(a)} ${op} ${this.formatDisplayNumber(b)} =`;
    
    this.addToHistory(exprText, formattedResult);

    this.currentValue = formattedResult;
    this.previousValue = null;
    this.operator = null;
    this.waitingForOperand = true;
  }

  // --- FUNCIONES CIENTÍFICAS INMEDIATAS (UNARIAS) ---
  applyUnary(funcName) {
    const val = parseFloat(this.currentValue);
    if (isNaN(val)) return;

    let res = 0;
    const isDeg = this.angleMode === 'deg';
    const toRad = (deg) => (deg * Math.PI) / 180;
    const toDeg = (rad) => (rad * 180) / Math.PI;

    let expr = `${funcName}(${this.currentValue})`;

    switch (funcName) {
      // Potencias y Raíces
      case 'sqr':
      case 'x²':
        res = val * val;
        expr = `sqr(${val})`;
        break;
      case 'cube':
      case 'x³':
        res = val * val * val;
        expr = `cube(${val})`;
        break;
      case 'sqrt':
      case '²√x':
        res = val < 0 ? NaN : Math.sqrt(val);
        expr = `√(${val})`;
        break;
      case 'cbrt':
      case '³√x':
        res = Math.cbrt(val);
        expr = `∛(${val})`;
        break;
      case 'recip':
      case '1/x':
        res = val === 0 ? NaN : 1 / val;
        expr = `1/(${val})`;
        break;
      case 'exp':
      case 'eˣ':
        res = Math.exp(val);
        expr = `e^(${val})`;
        break;
      case 'tenPow':
      case '10ˣ':
        res = Math.pow(10, val);
        expr = `10^(${val})`;
        break;
      case 'twoPow':
      case '2ˣ':
        res = Math.pow(2, val);
        expr = `2^(${val})`;
        break;

      // Logaritmos
      case 'ln':
        res = val <= 0 ? NaN : Math.log(val);
        expr = `ln(${val})`;
        break;
      case 'log10':
      case 'log₁₀':
        res = val <= 0 ? NaN : Math.log10(val);
        expr = `log(${val})`;
        break;
      case 'log2':
      case 'log₂':
        res = val <= 0 ? NaN : Math.log2(val);
        expr = `log2(${val})`;
        break;

      // Factorial
      case 'fact':
      case 'x!':
        if (val < 0 || !Number.isInteger(val) || val > 170) {
          res = NaN;
        } else {
          res = this.factorial(val);
        }
        expr = `${val}!`;
        break;

      // Trigonometría directa
      case 'sin': {
        const rad = isDeg ? toRad(val) : val;
        res = Math.sin(rad);
        // Limpieza de errores de redondeo comunes (ej. sin(180 deg) = 0)
        if (isDeg && val % 180 === 0) res = 0;
        break;
      }
      case 'cos': {
        const rad = isDeg ? toRad(val) : val;
        res = Math.cos(rad);
        if (isDeg && (val - 90) % 180 === 0) res = 0;
        break;
      }
      case 'tan': {
        const rad = isDeg ? toRad(val) : val;
        if (isDeg && (val - 90) % 180 === 0) res = NaN;
        else res = Math.tan(rad);
        break;
      }

      // Trigonometría inversa
      case 'asin':
      case 'sin⁻¹': {
        if (val < -1 || val > 1) res = NaN;
        else res = isDeg ? toDeg(Math.asin(val)) : Math.asin(val);
        break;
      }
      case 'acos':
      case 'cos⁻¹': {
        if (val < -1 || val > 1) res = NaN;
        else res = isDeg ? toDeg(Math.acos(val)) : Math.acos(val);
        break;
      }
      case 'atan':
      case 'tan⁻¹': {
        res = isDeg ? toDeg(Math.atan(val)) : Math.atan(val);
        break;
      }

      // Hiperbólicas
      case 'sinh': res = Math.sinh(val); break;
      case 'cosh': res = Math.cosh(val); break;
      case 'tanh': res = Math.tanh(val); break;
      case 'asinh':
      case 'sinh⁻¹': res = Math.asinh(val); break;
      case 'acosh':
      case 'cosh⁻¹': res = val < 1 ? NaN : Math.acosh(val); break;
      case 'atanh':
      case 'tanh⁻¹': res = (val <= -1 || val >= 1) ? NaN : Math.atanh(val); break;

      default:
        return;
    }

    const formatted = this.formatResult(res);
    this.addToHistory(`${expr} =`, formatted);
    this.currentValue = formatted;
    this.waitingForOperand = true;
  }

  factorial(n) {
    if (n === 0 || n === 1) return 1;
    let r = 1;
    for (let i = 2; i <= n; i++) r *= i;
    return r;
  }

  // --- CONSTANTES ---
  insertConstant(constName) {
    switch (constName) {
      case 'pi':
      case 'π':
        this.currentValue = this.formatResult(Math.PI);
        break;
      case 'e':
        this.currentValue = this.formatResult(Math.E);
        break;
      case 'rand':
      case 'Rand':
        this.currentValue = this.formatResult(Math.random());
        break;
    }
    this.waitingForOperand = true;
  }

  // --- MEMORIA ---
  memoryClear() {
    this.memory = 0;
  }

  memoryAdd() {
    const val = parseFloat(this.currentValue);
    if (!isNaN(val)) this.memory += val;
    this.waitingForOperand = true;
  }

  memorySubtract() {
    const val = parseFloat(this.currentValue);
    if (!isNaN(val)) this.memory -= val;
    this.waitingForOperand = true;
  }

  memoryRecall() {
    this.currentValue = this.formatResult(this.memory);
    this.waitingForOperand = true;
  }

  // --- CONTROLES DE MODO ---
  toggleAngleMode() {
    this.angleMode = this.angleMode === 'rad' ? 'deg' : 'rad';
    return this.angleMode;
  }

  toggleSecond() {
    this.isSecond = !this.isSecond;
    return this.isSecond;
  }

  // --- FORMATEO Y SALIDA VISUAL ---
  formatResult(num) {
    if (isNaN(num)) return 'Error';
    if (!isFinite(num)) return num > 0 ? 'Error' : '-Error';

    // Evita errores de punto flotante de IEEE 754 (ej. 0.1 + 0.2 = 0.30000000000000004)
    const prec = 12;
    const rounded = parseFloat(num.toPrecision(prec));

    // Si es un número muy grande o muy pequeño, usar notación científica limpia
    if (Math.abs(rounded) >= 1e16 || (Math.abs(rounded) > 0 && Math.abs(rounded) < 1e-9)) {
      return rounded.toExponential(8).replace(/e\+?/, 'e');
    }

    return String(rounded);
  }

  formatDisplayNumber(val) {
    if (typeof val === 'number') val = this.formatResult(val);
    if (val === 'Error' || val === '-Error') return 'Error';

    const parts = val.split('.');
    const integerPart = parts[0];
    const decimalPart = parts.length > 1 ? '.' + parts[1] : '';

    // Si está en notación científica
    if (val.includes('e')) return val;

    // Agregar separadores de miles
    const withCommas = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return withCommas + decimalPart;
  }

  getExpressionSummary() {
    if (this.previousValue !== null && this.operator) {
      return `${this.formatDisplayNumber(this.previousValue)} ${this.operator}`;
    }
    return '';
  }
}

window.TahoeCalculatorEngine = TahoeCalculatorEngine;
