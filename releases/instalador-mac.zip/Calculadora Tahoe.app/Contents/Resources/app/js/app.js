/**
 * Calculadora macOS Tahoe - Controlador de Interfaz de Usuario
 */

document.addEventListener('DOMContentLoaded', () => {
  const engine = new TahoeCalculatorEngine();
  const audio = new TahoeAudioFeedback();

  // Elementos DOM
  const calcWindow = document.getElementById('calcWindow');
  const mainResult = document.getElementById('mainResult');
  const expressionPreview = document.getElementById('expressionPreview');
  const copyTooltip = document.getElementById('copyTooltip');
  const badgeRad = document.getElementById('badgeRad');
  const badge2nd = document.getElementById('badge2nd');
  const btnClear = document.getElementById('btnClear');
  const tabBasic = document.getElementById('tabBasic');
  const tabSci = document.getElementById('tabSci');
  
  const historyDrawer = document.getElementById('historyDrawer');
  const historyList = document.getElementById('historyList');
  const btnHistory = document.getElementById('btnHistory');
  const btnCloseHistory = document.getElementById('btnCloseHistory');
  const btnClearHistory = document.getElementById('btnClearHistory');
  const historyBadge = document.getElementById('historyBadge');

  const btnSound = document.getElementById('btnSound');
  const soundIcon = document.getElementById('soundIcon');

  const btnInstall = document.getElementById('btnInstall');
  const installModal = document.getElementById('installModal');
  const btnCloseModal = document.getElementById('btnCloseModal');
  const btnInstallAction = document.getElementById('btnInstallAction');

  let deferredPrompt = null;
  let currentMode = 'basic'; // 'basic' o 'scientific'

  // --- ACTUALIZACIÓN DE PANTALLA ---
  function updateUI() {
    // 1. Número principal formateado
    const formatted = engine.formatDisplayNumber(engine.currentValue);
    mainResult.textContent = formatted;

    // 2. Ajuste dinámico de tamaño de fuente según longitud
    const len = formatted.length;
    if (len > 14) {
      mainResult.style.fontSize = '26px';
    } else if (len > 10) {
      mainResult.style.fontSize = '34px';
    } else if (len > 7) {
      mainResult.style.fontSize = '40px';
    } else {
      mainResult.style.fontSize = '48px';
    }

    // 3. Expresión previa
    expressionPreview.textContent = engine.getExpressionSummary();

    // 4. Texto del botón Limpiar (AC vs C)
    if (engine.currentValue !== '0') {
      btnClear.textContent = 'C';
    } else {
      btnClear.textContent = 'AC';
    }

    // 5. Estado de operador activo (resaltado blanco con texto naranja)
    document.querySelectorAll('.btn-op[data-op]').forEach(btn => {
      if (engine.waitingForOperand && engine.operator === btn.getAttribute('data-op')) {
        btn.classList.add('active-op');
      } else {
        btn.classList.remove('active-op');
      }
    });

    // 6. Insignias RAD/DEG y 2ND
    badgeRad.textContent = engine.angleMode.toUpperCase();
    badgeRad.classList.toggle('active', engine.angleMode === 'rad');
    badge2nd.classList.toggle('active', engine.isSecond);

    // 7. Contador de historial
    if (engine.history.length > 0) {
      historyBadge.style.display = 'block';
      historyBadge.textContent = engine.history.length > 99 ? '99+' : engine.history.length;
    } else {
      historyBadge.style.display = 'none';
    }

    // 8. Botón 2nd etiquetas dinámicas
    updateSecondFunctionKeys();
  }

  function updateSecondFunctionKeys() {
    const is2nd = engine.isSecond;
    const btn2nd = document.getElementById('btn2nd');
    if (btn2nd) btn2nd.classList.toggle('active', is2nd);

    const keys = {
      'btnSin': is2nd ? 'sin⁻¹' : 'sin',
      'btnCos': is2nd ? 'cos⁻¹' : 'cos',
      'btnTan': is2nd ? 'tan⁻¹' : 'tan',
      'btnSinh': is2nd ? 'sinh⁻¹' : 'sinh',
      'btnCosh': is2nd ? 'cosh⁻¹' : 'cosh',
      'btnTanh': is2nd ? 'tanh⁻¹' : 'tanh',
      'btnExp': is2nd ? 'yˣ' : 'eˣ',
      'btnTenPow': is2nd ? '2ˣ' : '10ˣ',
      'btnLn': is2nd ? 'log₂' : 'ln'
    };

    for (const [id, label] of Object.entries(keys)) {
      const el = document.getElementById(id);
      if (el) {
        el.textContent = label;
        el.setAttribute('data-func', label);
      }
    }
  }

  // --- EVENTOS DE BOTONES DE LA CALCULADORA ---
  document.querySelectorAll('.calc-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();

      // Sonido háptico
      if (btn.classList.contains('btn-op')) {
        audio.playClick(btn.getAttribute('data-action') === 'equals' ? 'equals' : 'operator');
      } else {
        audio.playClick('default');
      }

      // Animación de pulsación táctil
      btn.classList.add('pressed');
      setTimeout(() => btn.classList.remove('pressed'), 120);

      // Despacho de acciones
      const digit = btn.getAttribute('data-digit');
      const action = btn.getAttribute('data-action');
      const op = btn.getAttribute('data-op');
      const func = btn.getAttribute('data-func');
      const constant = btn.getAttribute('data-const');

      if (digit !== null) {
        engine.inputDigit(digit);
      } else if (action) {
        handleAction(action);
      } else if (op) {
        engine.setOperator(op);
      } else if (func) {
        engine.applyUnary(func);
      } else if (constant) {
        engine.insertConstant(constant);
      }

      updateUI();
    });
  });

  function handleAction(action) {
    switch (action) {
      case 'clear':
        engine.clear();
        break;
      case 'decimal':
        engine.inputDecimal();
        break;
      case 'sign':
        engine.toggleSign();
        break;
      case 'percent':
        engine.percentage();
        break;
      case 'equals':
        engine.calculateEquals();
        break;
      case 'radDeg':
        engine.toggleAngleMode();
        break;
      case 'second':
        engine.toggleSecond();
        break;
      case 'mc':
        engine.memoryClear();
        break;
      case 'm+':
        engine.memoryAdd();
        break;
      case 'm-':
        engine.memorySubtract();
        break;
      case 'mr':
        engine.memoryRecall();
        break;
    }
  }

  // --- CAMBIO DE MODO (BÁSICA vs CIENTÍFICA) ---
  function setMode(mode) {
    currentMode = mode;
    if (mode === 'scientific') {
      calcWindow.classList.add('mode-scientific');
      tabSci.classList.add('active');
      tabBasic.classList.remove('active');
    } else {
      calcWindow.classList.remove('mode-scientific');
      tabBasic.classList.add('active');
      tabSci.classList.remove('active');
    }
  }

  tabBasic.addEventListener('click', () => setMode('basic'));
  tabSci.addEventListener('click', () => setMode('scientific'));

  // Detección de orientación para teléfonos (Landscape -> Científica automática como iOS)
  window.addEventListener('resize', () => {
    if (window.innerWidth > window.innerHeight && window.innerHeight < 550) {
      setMode('scientific');
    }
  });

  // --- GESTIÓN DE HISTORIAL ---
  function renderHistory() {
    historyList.innerHTML = '';
    if (engine.history.length === 0) {
      historyList.innerHTML = '<div class="history-empty">Sin cálculos recientes</div>';
      return;
    }

    engine.history.forEach(item => {
      const div = document.createElement('div');
      div.className = 'history-item';
      div.innerHTML = `
        <span class="history-expr">${item.expression}</span>
        <span class="history-val">${item.result}</span>
      `;
      div.addEventListener('click', () => {
        engine.currentValue = item.result;
        engine.waitingForOperand = true;
        updateUI();
        historyDrawer.classList.remove('open');
        audio.playClick('default');
      });
      historyList.appendChild(div);
    });
  }

  btnHistory.addEventListener('click', () => {
    renderHistory();
    historyDrawer.classList.add('open');
    audio.playClick('default');
  });

  btnCloseHistory.addEventListener('click', () => {
    historyDrawer.classList.remove('open');
  });

  btnClearHistory.addEventListener('click', () => {
    engine.clearHistory();
    renderHistory();
    updateUI();
  });

  // --- SONIDO ---
  function updateSoundIcon() {
    if (audio.soundEnabled) {
      soundIcon.innerHTML = `
        <path d="M11 5L6 9H2v6h4l5 4V5z"/>
        <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>
      `;
      btnSound.title = 'Silenciar clics';
    } else {
      soundIcon.innerHTML = `
        <path d="M11 5L6 9H2v6h4l5 4V5z"/>
        <line x1="23" y1="9" x2="17" y2="15"/>
        <line x1="17" y1="9" x2="23" y2="15"/>
      `;
      btnSound.title = 'Activar clics';
    }
  }

  btnSound.addEventListener('click', () => {
    audio.toggleSound();
    updateSoundIcon();
    audio.playClick('default');
  });

  updateSoundIcon();

  // --- COPIAR AL PORTAPAPELES ---
  document.getElementById('calcDisplay').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(engine.currentValue);
      copyTooltip.classList.add('show');
      setTimeout(() => copyTooltip.classList.remove('show'), 1500);
      audio.playClick('default');
    } catch (err) {
      console.warn('No se pudo copiar:', err);
    }
  });

  // --- ENTRADA DE TECLADO ---
  window.addEventListener('keydown', (e) => {
    if (e.metaKey || e.ctrlKey) {
      if (e.key === 'c' || e.key === 'C') {
        // Permitir copiar normal
        return;
      }
      if (e.key === 'v' || e.key === 'V') {
        // Pegar número
        navigator.clipboard.readText().then(text => {
          const num = parseFloat(text.replace(/,/g, ''));
          if (!isNaN(num)) {
            engine.currentValue = engine.formatResult(num);
            engine.waitingForOperand = true;
            updateUI();
          }
        }).catch(() => {});
        return;
      }
    }

    let handled = true;
    if (e.key >= '0' && e.key <= '9') {
      engine.inputDigit(e.key);
      audio.playClick('default');
    } else if (e.key === '.' || e.key === ',') {
      engine.inputDecimal();
      audio.playClick('default');
    } else if (e.key === '+' || e.key === '-') {
      engine.setOperator(e.key);
      audio.playClick('operator');
    } else if (e.key === '*' || e.key === 'x' || e.key === 'X') {
      engine.setOperator('×');
      audio.playClick('operator');
    } else if (e.key === '/') {
      e.preventDefault();
      engine.setOperator('÷');
      audio.playClick('operator');
    } else if (e.key === 'Enter' || e.key === '=') {
      e.preventDefault();
      engine.calculateEquals();
      audio.playClick('equals');
    } else if (e.key === 'Escape') {
      engine.clear();
      audio.playClick('default');
    } else if (e.key === 'Backspace') {
      engine.backspace();
      audio.playClick('default');
    } else if (e.key === '%') {
      engine.percentage();
      audio.playClick('default');
    } else {
      handled = false;
    }

    if (handled) {
      updateUI();
    }
  });

  // --- ASISTENTE DE INSTALACIÓN MULTIPLATAFORMA (PWA & IOS) ---
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;

  // Si ya está instalado en modo standalone, ocultar botón de instalación
  if (isStandalone) {
    btnInstall.style.display = 'none';
  }

  // Interceptar evento PWA en Chrome / Edge / Android
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    btnInstall.style.display = 'flex';
  });

  btnInstall.addEventListener('click', () => {
    audio.playClick('default');
    if (deferredPrompt) {
      // Flujo nativo Chrome/Edge/Android
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult) => {
        if (choiceResult.outcome === 'accepted') {
          btnInstall.style.display = 'none';
        }
        deferredPrompt = null;
      });
    } else {
      // Mostrar modal instructivo adaptado (especialmente para iOS Safari o navegadores de escritorio)
      showInstallModal();
    }
  });

  function showInstallModal() {
    const modalDesc = document.getElementById('modalDesc');
    const modalSteps = document.getElementById('modalSteps');
    const btnAction = document.getElementById('btnInstallAction');

    if (isIOS) {
      modalDesc.textContent = 'Para instalar la Calculadora Tahoe en tu iPhone o iPad sin usar App Store:';
      modalSteps.innerHTML = `
        <div class="install-step-item">
          <div class="step-num">1</div>
          <div>Toca el botón <strong>Compartir</strong> en la barra inferior de Safari (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align:middle"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>)</div>
        </div>
        <div class="install-step-item">
          <div class="step-num">2</div>
          <div>Desplázate hacia abajo y selecciona <strong>"Agregar al inicio"</strong></div>
        </div>
        <div class="install-step-item">
          <div class="step-num">3</div>
          <div>Toca <strong>"Agregar"</strong> en la esquina superior derecha. ¡Listo!</div>
        </div>
      `;
      btnAction.textContent = '¡Entendido!';
      btnAction.onclick = () => installModal.classList.remove('show');
    } else {
      modalDesc.textContent = 'Disfruta de la Calculadora como una aplicación de escritorio nativa independiente:';
      modalSteps.innerHTML = `
        <div class="install-step-item">
          <div class="step-num">1</div>
          <div>En tu navegador (Chrome, Edge o Safari), haz clic en el icono de <strong>Instalar Aplicación</strong> en la barra de direcciones.</div>
        </div>
        <div class="install-step-item">
          <div class="step-num">2</div>
          <div>O también puedes usar los instaladores de 1 clic incluidos en la carpeta <strong>dist/</strong> para Windows, macOS y Android.</div>
        </div>
      `;
      btnAction.textContent = 'Cerrar';
      btnAction.onclick = () => installModal.classList.remove('show');
    }

    installModal.classList.add('show');
  }

  btnCloseModal.addEventListener('click', () => {
    installModal.classList.remove('show');
  });

  installModal.addEventListener('click', (e) => {
    if (e.target === installModal) {
      installModal.classList.remove('show');
    }
  });

  // Inicializar UI
  updateUI();
});
