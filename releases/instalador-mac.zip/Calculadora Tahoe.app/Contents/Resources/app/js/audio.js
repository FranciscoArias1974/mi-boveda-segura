/**
 * Calculadora macOS Tahoe - Síntesis de Sonido Háptico
 * Genera el sutil y elegante clic acústico característico de Apple
 */

class TahoeAudioFeedback {
  constructor() {
    this.ctx = null;
    this.soundEnabled = true;
    this.initFromStorage();
  }

  initFromStorage() {
    try {
      const saved = localStorage.getItem('tahoe_sound_enabled');
      if (saved !== null) {
        this.soundEnabled = saved === 'true';
      }
    } catch (e) {}
  }

  toggleSound() {
    this.soundEnabled = !this.soundEnabled;
    try {
      localStorage.setItem('tahoe_sound_enabled', String(this.soundEnabled));
    } catch (e) {}
    return this.soundEnabled;
  }

  ensureContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playClick(type = 'default') {
    if (!this.soundEnabled) return;
    try {
      this.ensureContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';
      
      if (type === 'operator') {
        // Tono un poco más cálido para operadores
        osc.frequency.setValueAtTime(420, now);
        osc.frequency.exponentialRampToValueAtTime(160, now + 0.035);
        filter.frequency.setValueAtTime(1800, now);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
      } else if (type === 'equals') {
        // Tono de resolución armónico sutil
        osc.frequency.setValueAtTime(580, now);
        osc.frequency.exponentialRampToValueAtTime(320, now + 0.06);
        filter.frequency.setValueAtTime(2400, now);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
      } else {
        // Clic nítido y suave característico de tecla numérica Apple
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(90, now + 0.025);
        filter.frequency.setValueAtTime(1400, now);
        gain.gain.setValueAtTime(0.07, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);
      }

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.08);
    } catch (e) {
      // Ignorar fallas silenciosas de audio en navegadores restringidos
    }
  }
}

window.TahoeAudioFeedback = TahoeAudioFeedback;
